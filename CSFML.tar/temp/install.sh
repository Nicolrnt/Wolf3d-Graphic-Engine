#! /bin/sh

add_to_bashrc_if_not_exist()
{
	grep -q -F "$1" ~/.bashrc || echo "$1" >> ~/.bashrc
}

if [ -d ~/.coding_club ];
then
	echo "Removing old .coding_club folder"
	rm -rf ~/.coding_club
fi

mkdir -p ~/.coding_club/lib
mkdir -p ~/.coding_club/include

echo "Copying development libraries."
cp -R -a lib/lib*.so* ~/.coding_club/lib/.
echo "Copying header files."
cp -R include/* ~/.coding_club/include/.

echo "Setting up environement variable."
add_to_bashrc_if_not_exist "### C Graphical Programming Environement Variable"
add_to_bashrc_if_not_exist "export LIBRARY_PATH=\$LIBRARY_PATH:${HOME}/.coding_club/lib:${HOME}/.graph_programming/lib"
add_to_bashrc_if_not_exist "export LD_LIBRARY_PATH=\$LIBRARY_PATH:${HOME}/.coding_club/lib:${HOME}/.graph_programming/lib"
add_to_bashrc_if_not_exist "export CPATH=\$CPATH:${HOME}/.coding_club/include:${HOME}/.graph_programming/include"

echo
echo "Please execute: source ~/.bashrc"
